package ecole.suptech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuptechProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
