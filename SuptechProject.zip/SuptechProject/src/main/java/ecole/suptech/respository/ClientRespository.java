package ecole.suptech.respository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.serv.entity.Client;

@Repository
public interface ClientRespository extends JpaRepository<Client,Long>{

	List<Client> findByNomClientContainingOrPrenomClientContaining(String nomClient, String prenomClient);
	
}
